﻿var formdata = new FormData();
$(document).ready(function () {
    $(".btn-agregar").on('click', function () {
        let IdTrabajador = $('#IdTrabajador').val();
        let NombreTrabajador = $('#NombreTrabajador').val();
        let FechaIngreso = $('#FechaIngreso').val();
        let FechaAntiguedad = $('#FechaAntiguedad').val();
        var IdCentroGasto = $("#IdCentroGasto").val();
        let DescripcionCentroGasto = $('#DescripcionCentroGasto').val();
        let IdPuesto = $('#IdPuesto').val();
        let DescripcionPuesto = $('#DescripcionPuesto').val();
        let IdCelda = $('#IdCelda').val();
        let DescripcionCelda = $('#DescripcionCelda').val();
        var IdGrupoNomina = $("#IdGrupoNomina").val();
        let SalarioDiario = $('#SalarioDiario').val();
        let SalarioIntegrado = $('#SalarioIntegrado').val();

        formdata.append('IdTrabajador', IdTrabajador)
        formdata.append('NombreTrabajador', NombreTrabajador)
        formdata.append('FechaIngreso', FechaIngreso)
        formdata.append('FechaAntiguedad', FechaAntiguedad)
        formdata.append('IdCentroGasto', IdCentroGasto)
        formdata.append('DescripcionCentroGasto', DescripcionCentroGasto)
        formdata.append('IdPuesto', IdPuesto)
        formdata.append('DescripcionPuesto', DescripcionPuesto)

        formdata.append('IdCelda', IdCelda)
        formdata.append('DescripcionCelda', DescripcionCelda)
        formdata.append('IdGrupoNomina', IdGrupoNomina)
        formdata.append('SalarioDiario', SalarioDiario)
        formdata.append('SalarioIntegrado', SalarioIntegrado)
        addVacante({});

    })
})

function addVacante(objData) {

    $.ajax({
        type: "POST",
        url: "AddVacante",
        data: formdata,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code == 201) {

            alert("Se agrego");
        } else {
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}