﻿var formdata = new FormData();
$(document).ready(function () {
    $(".btn-agregar").on('click', function () {
        formdata = new FormData();
        let User = $('#inputUsuario').val();
        let Pwd = $('#inputPassword').val();



        formdata.append('Usuario', User)
        formdata.append('Password', Pwd)



        addLogin({});

    })
})

function addLogin(objData) {

    $.ajax({
        type: "POST",
        url: "Login/getLogin",
        data: formdata,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code == 201) {
            $('#login').trigger('click');
        } else {
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}