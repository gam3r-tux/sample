﻿var formdata = new FormData();
var formdata2 = new FormData();

$(document).ready(function () {
    $("#Cobrador").on("change", function () {
        let Cobrador = $('#Cobrador').val();
        if (Cobrador == "") {
            alert("No Dejar el Campo vacio");
            return false;
        }
        else {
            formdata.append('Cobrador', Cobrador)

        }
        getCobrador({});
    })

    $("#NoCliente").on("change", function () {
        let NumCliente = $('#NoCliente').val()
        if (NumCliente == "") {
            alert("No Dejar el Campo vacio");
            return false;
        }
        else {
            formdata.append('NumCliente', NumCliente)

        }
        getNumCliente({});
    })


    $(".btn-agregar").on('click', function () {
        formdata = new FormData();
        let MailCobrador = $('#Cobrador').val();
        let NombreCobrado = $('#NombreCobrador').val();

        formdata.append('Cobrador', MailCobrador)
        formdata.append('NombreCobrador', NombreCobrado)

        addCobrador({});
    })

    $("#btnAddZona").on('click', function () {
        let Zona = $('#Zona').val();
        let Descripcion = $('#Descrip').val();

        formdata.append('Zona', Zona)
        formdata.append('Descripcion', Descripcion)

        addZona({});
    })

    $("#btnMidificar").on('click', function () {
        let Numcliente = $('#NoCliente').val();
        let NomCliente = $('#NombreCliente').val();
        let Cobrador = $('#Cobrador').val();
        let Zona = $('#ZonaCobranza').val();
        let Filial = $('#FilialC').prop('checked');

        formdata2.append('Numcliente', Numcliente)
        formdata2.append('NomCliente', NomCliente)
        formdata2.append('Cobrador', Cobrador)
        formdata2.append('Zona', Zona)
        formdata2.append('Filial', Filial)

        ModDimCustomer({});
    })

})

function getCobrador(objData) {

    $.ajax({
        type: "POST",
        url: "mttoCobradores",
        data: formdata,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code != null) {
            $("#NombreCobrador").val(response.code);
        } else {
            alert("No se Encontro Cobrador");
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}

function getNumCliente(objData) {

    $.ajax({
        type: "POST",
        url: "mttoDatosClientes",
        data: formdata,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code != null) {

            $("#NombreCliente").val(response.code);
            $("#NombreCliente").show();
            $("#Modif").show();
            $("#nomCliente").show();

        } else {
            alert("No se Encontro Cobrador");
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}

function addCobrador(objData) {

    $.ajax({
        type: "POST",
        url: "AddCobradores",
        data: formdata,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code == 201) {
            alert("Registro Guardado Exitosamente");
            window.open('MantenimientoCobradores', '_self');
        } else {
            alert("No se Encontro Cobrador");
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}

function addZona(objData) {

    $.ajax({
        type: "POST",
        url: "mttoZonaCobranza",
        data: formdata,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code == 201) {
            alert("Registro Guardado Exitosamente");
            window.open('MantenimientoZonaCobranza', '_self');
        } else {
            alert("No se Guardo el Registro");
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}

function ModDimCustomer(objData) {

    $.ajax({
        type: "POST",
        url: "modDimCustomer",
        data: formdata2,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code == 201) {
            alert("Registro Guardado Exitosamente");
            window.open('MantenimientoDatosAdicionalesCliente', '_self');
        } else {
            alert("No se Guardo el Registro");
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}