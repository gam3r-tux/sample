﻿var formdata = new FormData();
var formdata2 = new FormData();
var formdata3 = new FormData();

$(document).ready(function () {
    $(".btn-agregar").on('click', function () {
        formdata2 = new FormData();
        let Company = $('#Compañia').val();
        let FechaDoc = $('#FechaDoc').val();
        let Documento = $('#Documento').val();
        let UUID = $('#UUID').val();
        let NoCliente = $('#NoCliente').val();

        formdata2.append('Company', Company)
        formdata2.append('FechaDoc', FechaDoc)
        formdata2.append('Documento', Documento)
        formdata2.append('UUID', UUID)
        formdata2.append('NoCliente', NoCliente)

        getUUIDs({});

    })

    $("#btnGuardar").on('click', function () {
        formdata = new FormData();
        let FechaDocAct = $('#FechaDocAct').val();
        let DocumentoAct = $('#DocumentoAct').val();
        let UUIDAct = $('#UUIDAct').val();
        let UUIDOr = $('#UUIDOr').val();
        let RFC = $('#RFC').val();
        let Company = $('#Compañia').val();
        let NoDocOr = $('#NoDocOr').val();
        let FeDocOr = $('#FeDocOr').val();

        formdata.append('FechaDocAct', FechaDocAct)
        formdata.append('DocumentoAct', DocumentoAct)
        formdata.append('UUIDAct', UUIDAct)
        formdata.append('UUIDOr', UUIDOr)
        formdata.append('RFC', RFC)
        formdata.append('Company', Company)
        formdata.append('NoDocOr', NoDocOr)
        formdata.append('FeDocOr', FeDocOr)

        if (UUIDAct != "") {

            REPLACEUUIDs({});
        }
        else {
            alert("No Dejar el Campo UUID vacio");
        }


    })

    $("#UUIDAct").on("change", function () {
        let UUIDAct = $('#UUIDAct').val();
        let UUIDOr = $('#UUIDOr').val();
        if (UUIDAct == "") {
            alert("No Dejar el Campo UUID vacio");
            return false;
        }
        else {
            if (UUIDAct.trim() == UUIDOr.trim()) {
                alert("El UUID debe ser Distinto al Anterior");
                $("#UUIDAct").val('');
                return false;
            }
            else {

                if (UUIDAct.length == 36) {

                }
                else {
                    alert("El UUID debe tener 36 Caracteres");
                    $("#UUIDAct").val('');
                }
            }

        }
    })

    $("#UUID").on("change", function () {
        let UUIDAct = $('#UUID').val();
        if (UUIDAct != "") {
            if (UUIDAct.trim().length == 36) {

            }
            else {
                alert("El UUID debe tener 36 Caracteres");
                $("#UUID").val('');
            }
        }
    })

})
function getUUIDs(objData) {

    $.ajax({
        type: "POST",
        url: "GETUUIDS",
        data: formdata2,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code != null) {
            //$("#NombreCobrador").val(response.code);
            if (response.code == 202) {
                var table = document.getElementById('itemTable');
                table.style.display = "none";
                alert("No se Encontro Informacion");

            }
            else {
                var parsedItems = response.code.split('▓');
                addOrder(parsedItems);
            }

        } else {
            alert("No se Encontro Informacion");
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}

function REPLACEUUIDs(objData) {

    $.ajax({
        type: "POST",
        url: "REPLACEUUIDS",
        data: formdata,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code != null) {
            //ReSearch(response.fecha, response.documento, response.uuid);
            document.getElementById("btnBuscar").click();
            //$("#NombreCobrador").val(response.code);
            //var parsedItems = response.code.split('▓');
            //addOrder(parsedItems);
            dismissModal(event)
            $("#UUIDAct").val('');
            $("#RFC").val('');
            $("#NoDocOr").val('');
            $("#FeDocOr").val('');
        } else {
            alert("No se Encontro Informacion");
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}

function ReSearch(fecha, documento, uuid) {
    formdata2 = new FormData();
    let Company = $('#Compañia').val();
    let FechaDoc = $('#FechaDoc').val();
    let Documento = $('#Documento').val();
    let UUID = $('#UUID').val();
    let NoCliente = $('#NoCliente').val();

    if (FechaDoc != '') {
        FechaDoc = fecha;
    }

    if (Documento != '') {
        Documento = documento;
    }

    if (UUID != '') {
        UUID = uuid;
    }

    formdata2.append('Company', Company)
    formdata2.append('FechaDoc', FechaDoc)
    formdata2.append('Documento', Documento)
    formdata2.append('UUID', UUID)
    formdata2.append('NoCliente', NoCliente)

    getUUIDs({});
}