﻿$(document).ready(function () {
    var nowDate = new Date();
    var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);
    $('.datepicker').datepicker({
        dateFormat: "mm/dd/yy"
    });
    $('.filtrosFechas').datepicker({
        dateFormat: "yy-mm-dd"
    });
    $('#ModalResult').on('hidden.bs.modal', function (e) {
        $('body').html('');
        window.location.reload();

    });


    $('.btn-filter').on('click', function () {
        var filter1 = $("#plan-val").val()
        var filter2 = $("#clase-val").val()
        var opcion = $("#OpcionesFiltro").val();
        if (filter2 != "" && filter1 != "") {

            var rows = document.querySelector("#table1 tbody").rows;

            for (var i = 0; i < rows.length; i++) {
                var claseManufactura = rows[i].cells[15].textContent.toUpperCase();
                var planeador = rows[i].cells[16].textContent.toUpperCase();
                if (claseManufactura == (filter2.toUpperCase()) && planeador == (filter1.toUpperCase())) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        } else {
            if (filter1 != "") {
                $(".table-explorer tbody td.buyer:contains('" + filter1 + "')").parent().show();
                $(".table-explorer tbody td.buyer:not(:contains('" + filter1 + "'))").parent().hide();
            }

            if (filter2 != "") {
                $(".table-explorer tbody td.clase:contains('" + filter2 + "')").parent().show();
                $(".table-explorer tbody td.clase:not(:contains('" + filter2 + "'))").parent().hide();
            }
        }
        var countShowed = $('.table-explorer tbody tr:not([style*="display: none"])').length
        $(".title-reporte span").html("Número de registros: " + countShowed);
    });

    $('.btn-filter-oc').on('click', function () {
        var filter1 = $("#plan-val").val()
        var filter2 = $("#prov-val").val()
        var opcion = $("#OpcionesFiltro").val();
        if (filter2 != "" && filter1 != "") {

            var rows = document.querySelector(".table-explorer tbody").rows;

            for (var i = 0; i < rows.length; i++) {
                var firstCol = $(rows[i].cells[11]).find('input').val().toUpperCase();
                var secondCol = rows[i].cells[19].textContent.toUpperCase();
                if (firstCol == (filter2.toUpperCase()) && secondCol == (filter1.toUpperCase())) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        } else {
            if (filter2 != "") {
                var rows = document.querySelector(".table-explorer tbody").rows;

                for (var i = 0; i < rows.length; i++) {
                    var firstCol = $(rows[i].cells[11]).find('input').val().toUpperCase();
                    if (firstCol == (filter2.toUpperCase())) {
                        rows[i].style.display = "";
                    } else {
                        rows[i].style.display = "none";
                    }
                }
            }

            if (filter1 != "") {
                $(".table-explorer tbody td.buyer:contains('" + filter1 + "')").parent().show();
                $(".table-explorer tbody td.buyer:not(:contains('" + filter1 + "'))").parent().hide();
            }
        }

        var countShowed = $('.table-explorer tbody tr:not([style*="display: none"])').length
        $(".title-reporte span").html("Número de registros: " + countShowed);

    });

    $('.mark-item').on('click', function () {
        if ($(this).hasClass("marcar")) {
            $(this).removeClass("marcar");
            $(this).addClass("desmarcar");
            $(this).parent().parent().parent().addClass("orden");
        } else {
            $(this).removeClass("desmarcar");
            $(this).addClass("marcar");
            $(this).parent().parent().parent().removeClass("orden");
        }


    })

    $('.mark-todos').on('click', function () {
        $('.table-explorer tbody tr').each(function (i) {
            if (!$(this).is(":hidden")) {


                if ($(this).find('.mark-item').hasClass("marcar")) {
                    $(this).find('.mark-item').removeClass("marcar");
                    $(this).find('.mark-item').addClass("desmarcar");
                    $(this).find('.mark-item').parent().parent().parent().addClass("orden");
                    $(this).find('.mark-item').prop('checked', true);
                } else {
                    $(this).find('.mark-item').removeClass("desmarcar");
                    $(this).find('.mark-item').addClass("marcar");
                    $(this).find('.mark-item').parent().parent().parent().removeClass("orden");
                    $(this).find('.mark-item').prop('checked', false);
                }
            }

        })


    })

    $(".btn-add").on('click', function () {
        $("#ModalConfirmacion").modal({ backdrop: 'static', keyboard: false });
    })

    $("#Aceptar-btn").on('click', function () {
        var objData = [];
        var objData2 = [];
        $('#ModalConfirmacion').modal('toggle')
        $('#ModalProcessing').modal({ backdrop: 'static', keyboard: false });

            
        $('.orden').each(function (i) {
            console.log("a");
            var _obj = {};
            var _sug = {};
            var site = '1000';
            var vencimiento = $(this).find('.datepicker').val();
            var articulo = $(this).find('.articulo').html();
            var sugerida = $(this).find('.sugerida').html();
            var cantidad = $(this).find('.cantidad input').val();
            var comentario = $(this).find('.comentario textarea').val();
            var fechaOriginal = $(this).find('.FechaOriginal').html();

            _obj = { 'NumParte': articulo, 'Planta': site, 'Cantidad': cantidad, 'FecVen': vencimiento }
            _sug = { 'NumParte': articulo, Sugerida: sugerida, Comentario: comentario, FechaOriginal: fechaOriginal }
            objData.push(_obj);
            objData2.push(_sug);
        })
        setTimeout(function () {
            //your code to be executed after 1 second
            AgregarPT({ obj: objData, sug: objData2 });
        }, 1000);
        
    })

    $(".btn-add-OC").on('click', function () {
        $("#ModalConfirmacion").modal({ backdrop: 'static', keyboard: false });
    })

    $("#Aceptar-btn-oc").on('click', function () {

        var objData = [];
        var objData2 = [];
        $('#ModalConfirmacion').modal('toggle')
        $('#ModalProcessing').modal({ backdrop: 'static', keyboard: false });

        $('.orden').each(function (i) {
            console.log("a");
            var _obj = {};
            var _sug = {};
            var site = '1000';
            var fecPlanta = $(this).find('.datepicker').val();
            var articulo = $(this).find('.articulo').html();
            var sugerida = $(this).find('.sugerida').html();
            var proveedor = $(this).find('.proveedor input').val();
            var cantidad = $(this).find('.cantidad input').val();
            var embarcarA = $(this).find('.EmbarcarA input').val();
            var incoterm = $(this).find('.proveedor').attr('term');
            var monFlete = $(this).find('.MonFlete input').val();
            var leadTime = $(this).find('.vencimiento').attr('lead');
            var consignacionCheck = $(this).find('.mark-consig');
            var comprador = gComprador;
            var tipo = $(this).find('.tipo-orden').val();
            var fechaOriginal = $(this).find('.FechaOriginal').html();

            var consignacion = 'NO';
            if (consignacionCheck.is(':checked')) {
                consignacion = 'YES';
            }
            var comentario = $(this).find('.comentario textarea').val();
            _obj = {
                'NumProveedor': proveedor, 'EmbarcarA': embarcarA, 'Planta': site, 'Comprador': comprador, 'Incoterm': incoterm,
                'TipoOrden': tipo, 'MonFlete': monFlete,
                'Consignacion': consignacion, 'NumParte': articulo, 'Cantidad': cantidad, 'FecPlanta': fecPlanta, LeadTime: leadTime
            }
            _sug = { 'NumParte': articulo, Sugerida: sugerida, Comentario: comentario, FechaOriginal: fechaOriginal }
            objData.push(_obj);
            objData2.push(_sug);
        })
        setTimeout(function () {
            //your code to be executed after 1 second
            AgregarMP({ obj: objData, sug: objData2 });
        }, 1000);
    })

    $(".btn-get-info").on('click', function () {

        var fecha1 = $("#from-date").val();
        var fecha2 = $("#to-date").val();

        if (fecha1 == "" || fecha2 == "") {
            alert("Se requiere un rango de fechas")
            return false;
        }
        $('#ModalProcessing').modal('toggle');
        $("#table-explorer tbody").html('');

        setTimeout(function () {
            GetInfoRetail(fecha1, fecha2);
        }, 1000);
    })
});


function GetInfoRetail(fecha1, fecha2) {
    $.ajax({
        type: "POST",
        url: "GetRetailMTO",
        data: { fechaInicial: fecha1, fechaFinal: fecha2 },
        dataType: "json"

    }).done(function (response) {
        console.log(response);
        $('#ModalProcessing').modal('toggle')
        if (response.code == 201) {
            response.data.forEach(function (item, indice) {
                var row =
                "<tr>" +
                    "<td>" + '<div class="form-check"><input type="checkbox" class="form-check-input mark-item marcar" > </div>' + "</td>" +
                    "<td>" + item.sod_nbr + "</td>" +
                    "<td>" + item.so_cust + "</td>" +
                    "<td>" + item.ad_name + "</td>" +
                    "<td>" + item.sod_line + "</td>" +
                    "<td>" + item.sod_part + "</td>" +
                    "<td>" + item['local-var01'] + "</td>" +
                    "<td>" + item['local-var08'] + "</td>" +
                    "<td>" + item['local-var08']+ "</td>" +
                    "<td>" + item.sod_due_date + "</td>" +
                    "<td>" + item.FechaPlanta + "</td>" +
                    "<td>" + item.FechaPlanta + "</td>" +
                    "<td>" + item.ptp_vend + "</td>" +
                    "<td>" + item["local-var03"] + "</td>" +
                    "<td>" + item.in_qty_avail + "</td>" +
                    "<td>" + item.ptp_pur_lead + "</td>" +
                    "<td>" + item.ptp_ord_min + "</td>" +
                    "<td>" + item.ptp_ord_mult + "</td>" +
                    "<td>" + "Embarcar A" + "</td>" +
                    "<td>" + "checkConsig" + "</td>" +
                    "<td>" + "listTipoOrden" + "</td>" +
                    "<td>" + "MonFlete" + "</td>" +
                    "<td>" + item.KIT + "</td>" +
                    "<td>" + '<textarea class="form-control" rows="3"></textarea>' + "</td>" +
                    "</tr>"
                $(".table-explorer tbody").append(row);
            })

            response.dataKits.forEach(function (item, indice) {

            })

        } else {
            alert("Error al agregar")
        }

    }).fail(function (jqXHR) {
        alert("Error del servidor")
        $('#ModalProcessing').modal('toggle')
    });
}
function AgregarPT(data) {
    $.ajax({
        type: "POST",
        url: "AgregarOrdenesTrabajo",
        data: { form: data.obj, sugerida: data.sug },
        dataType: "json"

    }).done(function (response) {
        console.log(response);
        $('#ModalProcessing').modal('toggle')
        if (response.code == 201) {

            response.dataCreadas.forEach(function (item, indice) {
                var row = "<tr>" +
                    "<th>" + item.Ordrab + "</th>" +
                    "<th>" + item.Id + "</th>" +
                    "<th>" + item.Status + "</th>" +
                    "<th>" + item.NumParte + "</th>" +
                    "<th>" + item.Descripcion + "</th>" +
                    "<th>" + item.Planta + "</th>" +
                    "<th>" + item.Canidad + "</th>" +
                    "<th>" + item.FechaOT + "</th>" +
                    "<th>" + item.FecLiberacion + "</th>" +
                    "<th>" + item.Fecvencimiento + "</th>" +
                    "</tr>"
                $("#table-creadas tbody").append(row);
            });

            response.dataFaltantes.forEach(function (item, indice) {
                var row2 = "<tr>" +
                    "<th>" + item.OrdTrab + "</th>" +
                    "<th>" + item.Id + "</th>" +
                    "<th>" + item.Estatus + "</th>" +
                    "<th>" + item.NumParte + "</th>" +
                    "<th>" + item.Componente + "</th>" +
                    "<th>" + item.Descripcion + "</th>" +
                    "<th>" + item.Planta + "</th>" +
                    "<th>" + item.CanReq + "</th>" +
                    "<th>" + item.CanInv + "</th>" +
                    "<th>" + item.CanFal + "</th>" +

                    "<th>" + item.TipoORden + "</th>" +
                    "<th>" + item.Proveedor + "</th>" +
                    "<th>" + item.NombreProveedor + "</th>" +
                    "<th>" + item.LeadTime + "</th>" +
                    "<th>" + item.Critical + "</th>" +
                    "<th>" + item.InvConsig + "</th>" +
                    "</tr>"
                $("#table-faltantes tbody").append(row2);
            });
            //tableToExcel('table-creadas', 'name')
            tablesToExcel(['table-creadas', 'table-faltantes'], ['creadas', 'faltantes'], 'OTs.xls', 'Excel')
            $('#ModalResult').modal({ backdrop: 'static', keyboard: false });
        } else {
            alert("Error al agregar")
        }

    }).fail(function (jqXHR) {
        alert("Error del servidor")
        $('#ModalProcessing').modal('toggle')
    });
}


function AgregarMP(data) {
    $.ajax({
        type: "POST",
        url: "AgregarOrdenesCompra",
        data: { form: data.obj, sugerida: data.sug },
        dataType: "json"

    }).done(function (response) {
        console.log(response);
        $('#ModalProcessing').modal('toggle')
        if (response.code == 201) {

            response.dataCreadas.forEach(function (item, indice) {
                var row = "<tr>" +
                    "<th>" + item.OrdCompra + "</th>" +
                    "<th>" + item.Consignacion + "</th>" +
                    "<th>" + item.Proveedor + "</th>" +
                    "<th>" + item.EmbarcarA + "</th>" +
                    "<th>" + item.Planta + "</th>" +
                    "<th>" + item.FecOrden + "</th>" +
                    "<th>" + item.FecPlanta + "</th>" +
                    "<th>" + item.FecProvee + "</th>" +
                    "<th>" + item.FecAduana + "</th>" +
                    "<th>" + item.Partida + "</th>" +
                    "<th>" + item.NumParte + "</th>" +
                    "<th>" + item.Cantidad + "</th>" +
                    "</tr>"
                $("#table-creadas tbody").append(row);
            });

            response.dataErrores.forEach(function (item, indice) {
                var row2 = "<tr>" +
                    "<th>" + item.NumProvee + "</th>" +
                    "<th>" + item.EmbarcarA + "</th>" +
                    "<th>" + item.NumParte + "</th>" +
                    "<th>" + item.Error + "</th>" +
                    "</tr>"
                $("#table-errores tbody").append(row2);
            });
            //tableToExcel('table-creadas', 'name')
            tablesToExcel(['table-creadas', 'table-errores'], ['creadas', 'faltantes'], 'OCs.xls', 'Excel')
            $('#ModalResult').modal({ backdrop: 'static', keyboard: false });
        } else {
            if (response.code == 203) {
                alert("Proveedor no valido")
            } else {
                alert("Error al agregar")
            }
        }

    }).fail(function (jqXHR) {
        $('#ModalProcessing').modal('toggle')
        alert("Error del servidor")
    });
}
var tablesToExcel = (function () {
    var uri = 'data:application/vnd.ms-excel;base64,'
        , tmplWorkbookXML = '<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
            + '<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office"><Author>Axel Richter</Author><Created>{created}</Created></DocumentProperties>'
            + '<Styles>'
            + '<Style ss:ID="Currency"><NumberFormat ss:Format="Currency"></NumberFormat></Style>'
            + '<Style ss:ID="Date"><NumberFormat ss:Format="Medium Date"></NumberFormat></Style>'
            + '</Styles>'
            + '{worksheets}</Workbook>'
        , tmplWorksheetXML = '<Worksheet ss:Name="{nameWS}"><Table>{rows}</Table></Worksheet>'
        , tmplCellXML = '<Cell{attributeStyleID}{attributeFormula}><Data ss:Type="{nameType}">{data}</Data></Cell>'
        , base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
        , format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
    return function (tables, wsnames, wbname, appname) {
        var ctx = "";
        var workbookXML = "";
        var worksheetsXML = "";
        var rowsXML = "";

        for (var i = 0; i < tables.length; i++) {
            if (!tables[i].nodeType) tables[i] = document.getElementById(tables[i]);
            for (var j = 0; j < tables[i].rows.length; j++) {
                rowsXML += '<Row>'
                for (var k = 0; k < tables[i].rows[j].cells.length; k++) {
                    var dataType = tables[i].rows[j].cells[k].getAttribute("data-type");
                    var dataStyle = tables[i].rows[j].cells[k].getAttribute("data-style");
                    var dataValue = tables[i].rows[j].cells[k].getAttribute("data-value");
                    dataValue = (dataValue) ? dataValue : tables[i].rows[j].cells[k].innerHTML;
                    var dataFormula = tables[i].rows[j].cells[k].getAttribute("data-formula");
                    dataFormula = (dataFormula) ? dataFormula : (appname == 'Calc' && dataType == 'DateTime') ? dataValue : null;
                    ctx = {
                        attributeStyleID: (dataStyle == 'Currency' || dataStyle == 'Date') ? ' ss:StyleID="' + dataStyle + '"' : ''
                        , nameType: (dataType == 'Number' || dataType == 'DateTime' || dataType == 'Boolean' || dataType == 'Error') ? dataType : 'String'
                        , data: (dataFormula) ? '' : dataValue
                        , attributeFormula: (dataFormula) ? ' ss:Formula="' + dataFormula + '"' : ''
                    };
                    rowsXML += format(tmplCellXML, ctx);
                }
                rowsXML += '</Row>'
            }
            ctx = { rows: rowsXML, nameWS: wsnames[i] || 'Sheet' + i };
            worksheetsXML += format(tmplWorksheetXML, ctx);
            rowsXML = "";
        }

        ctx = { created: (new Date()).getTime(), worksheets: worksheetsXML };
        workbookXML = format(tmplWorkbookXML, ctx);



        var link = document.createElement("A");
        link.href = uri + base64(workbookXML);
        link.download = wbname || 'Workbook.xls';
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
})();