﻿$(document).ready(function () {

    hideDiv();
    $("#divGhost").css("display", "block");

    $(".cbTipoCedula").change(function () {
        //alert("Option --> " + $(".cbTipoCedula").val());
        if ($(".cbTipoCedula").val() == "0") {
            hideDiv();
            $("#divGhost").css("display", "block");
        }

        if ($(".cbTipoCedula").val() == "12") {
            hideDiv();
            $("#divHCC12").css("display", "block")
        }

        if ($(".cbTipoCedula").val() == "13") {
            hideDiv();
            $("#divHCC13").css("display", "block")
        }

        if ($(".cbTipoCedula").val() == "EF") {
            hideDiv();
            $("#divEFINTERNOS").css("display", "block")
        }

        if ($(".cbTipoCedula").val() == "ER") {
            hideDiv();
            $("#divER").css("display", "block")
        }

    });

    $("#checkboxAll12").change(function () {
        $(':checkbox').prop("checked", this.checked);
    });
    $("#checkboxAll13").change(function () {
        $(':checkbox').prop("checked", this.checked);
    });
    $("#checkboxAllEF").change(function () {
        $(':checkbox').prop("checked", this.checked);
    });
    $("#checkboxAllER").change(function () {
        $(':checkbox').prop("checked", this.checked);
    });

    $body = $("body");

    $(document).on({
        ajaxStart: function () { $body.addClass("loading"); },
        ajaxStop: function () { $body.removeClass("loading"); }
    });

});

function hideDiv() {
    $("#divGhost").css("display", "none")
    $("#divHCC12").css("display", "none")
    $("#divHCC13").css("display", "none")
    $("#divEFINTERNOS").css("display", "none")
    $("#divER").css("display", "none")

    $("#checkboxAll12").prop("checked", false);
    $("#checkboxAll13").prop("checked", false);
    $("#checkboxAllEF").prop("checked", false);
    $("#checkboxAllER").prop("checked", false);

    $('#checkboxes12 input:checked').each(function () {
        $(this).prop("checked", false);
    });
    $('#checkboxes13 input:checked').each(function () {
        $(this).prop("checked", false);
    });
    $('#checkboxesEF input:checked').each(function () {
        $(this).prop("checked", false);
    });
    $('#checkboxesER input:checked').each(function () {
        $(this).prop("checked", false);
    });
}

function ValidarCampos() {
    var selected = [];

    if ($(".cbTipoCedula").val() == "0") {
        alert("Debe seleccionar un Tipo de Cédula");
        return false;
    }

    if ($(".cbTipoCedula").val() == "12") {

        $('#checkboxes12 input:checked').each(function () {
            if ($(this).val() != "on") {
                selected.push($(this).val());
            }
        });

        if (selected.length == 0) {
            alert("Debe seleccionar al menos una Cédula, marcando su casilla");
            return false;
        }
    }

    if ($(".cbTipoCedula").val() == "13") {

        $('#checkboxes13 input:checked').each(function () {
            if ($(this).val() != "on") {
                selected.push($(this).val());
            }
        });

        if (selected.length == 0) {
            alert("Debe seleccionar al menos una Cédula, marcando su casilla");
            return false;
        }
    }

    if ($(".cbTipoCedula").val() == "EF") {

        $('#checkboxesEF input:checked').each(function () {
            if ($(this).val() != "on") {
                selected.push($(this).val());
            }
        });

        if (selected.length == 0) {
            alert("Debe seleccionar al menos una Cédula, marcando su casilla");
            return false;
        }
    }

    if ($(".cbTipoCedula").val() == "ER") {

        $('#checkboxesER input:checked').each(function () {
            if ($(this).val() != "on") {
                selected.push($(this).val());
            }
        });

        if (selected.length == 0) {
            alert("Debe seleccionar al menos una Cédula, marcando su casilla");
            return false;
        }
    }

    if ($(".cbAnio").val() == "0") {
        alert("Debe seleccionar un Año");
        return false;
    }

    if ($(".cbPeriodo").val() == "0") {
        alert("Debe seleccionar un Periodo");
        return false;
    }

    return true;
}

function fnCalcular() {

    if (ValidarCampos()) {
        var selected = [];

        if ($(".cbTipoCedula").val() == "12") {

            $('#checkboxes12 input:checked').each(function () {
                if ($(this).val() != "on") {
                    selected.push($(this).val());
                }
            });
        }

        if ($(".cbTipoCedula").val() == "13") {

            $('#checkboxes13 input:checked').each(function () {
                if ($(this).val() != "on") {
                    selected.push($(this).val());
                }
            });
        }

        if ($(".cbTipoCedula").val() == "EF") {

            $('#checkboxesEF input:checked').each(function () {
                if ($(this).val() != "on") {
                    selected.push($(this).val());
                }
            });
        }

        if ($(".cbTipoCedula").val() == "ER") {

            $('#checkboxesER input:checked').each(function () {
                if ($(this).val() != "on") {
                    selected.push($(this).val());
                }
            });
        }

        var objJ = {
            data: {
                "Anio": $(".cbAnio").val(),
                "Periodo": $(".cbPeriodo").val(),
                "TipoCedula": $(".cbTipoCedula").val(),
                "Cedulas": selected.join(",")
            }
        };
        //alert(JSON.stringify(objJ));
        // ejecuta llamada ajax
        getExcelFile(objJ);
    }
    return true;
}

function getExcelFile(obj) {

    $.ajax({
        async: true,
        type: "POST",
        url: "Cedulas/GetExcelFileProcessed",
        data: obj,
        dataType: 'json',
        cache: false,
        success: function (response) {
            if (response.code == 201) {
                window.location = 'Cedulas/Download?file=' + response.data;
            }
        }
            });
        }

function fnReset() {
    hideDiv();
    $("#divGhost").css("display", "block")
    $(".cbTipoCedula").val("0").change();
    $(".cbAnio").val("0").change();
    $(".cbPeriodo").val("0").change();
}
