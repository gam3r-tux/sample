﻿var formdata = new FormData();
$(document).ready(function () {
    $(".btn-agregar").on('click', function () {
        let Aduana = $('#Aduana').val();
        let Patente = $('#Patente').val();
        let Pedimento = $('#Pedimento').val();
        let NumProveedor = $('#NumProveedor').val();
        let ValorDolares = $('#ValorDolares').val();
        let CantidadLibras = $('#CantidadLibras').val();
        let FechaPago = $('#FechaPago').val();
        let TipoPedimento = $('#TipoPedimento').val();
        let Consolidado = $('#Consolidado').prop('checked');;


        formdata.append('Aduana', Aduana)
        formdata.append('Patente', Patente)
        formdata.append('Pedimento', Pedimento)
        formdata.append('NumProveedor', NumProveedor)
        formdata.append('ValorDolares', ValorDolares)
        formdata.append('CantidadLibras', CantidadLibras)
        formdata.append('FechaPago', FechaPago)
        formdata.append('TipoPedimento', TipoPedimento)
        formdata.append('Consolidado', Consolidado)

       
        addPedimento({});

    })
})

function addPedimento(objData) {

    $.ajax({
        type: "POST",
        url: "AddPedimento",
        data: formdata,
        dataType: "json",
        processData: false,
        contentType: false,
    }).done(function (response) {
        console.log(response);
        if (response.code == 201) {

            alert("Registro Guardado Exitosamente");
            window.open('CargaManual', '_self');
        } else {
            alert("No se Guardo el Registro");
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}

$(document).ready(function () {

    $("#Aduana").on("change", function () {

        let ubicacion = $('#Aduana').val()
        if (ubicacion == "") {
            alert("No Dejar el Campo vacio");
            return false;
        }
        if (ubicacion == "") {
            alert("No Dejar el Campo vacio");
            return false;
        }

        if (ubicacion.length < 3) {
            alert("Minimo 3 Digitos");
            return false;
        }
    })

    $("#Patente").on("change", function () {

        let ubicacion = $('#Patente').val()

        if (ubicacion == "") {
            alert("No Dejar el Campo vacio");
            return false;
        }

        if (ubicacion.length < 4) {
            alert("Minimo 4 Digitos");
            return false;
        }
    })

    $("#Pedimento").on("change", function () {

        let ubicacion = $('#Pedimento').val()

        if (ubicacion == "") {
            alert("No Dejar el Campo vacio");
            return false;
        }

        if (ubicacion.length < 7) {
            alert("Minimo 7 Digitos");
            return false;
        }
    })

    $("#ValorDolares").on("change", function () {

        let ubicacion = $('#ValorDolares').val()

        if (ubicacion == "") {
            alert("No Dejar el Campo vacio");
            return false;
        }
    })

    $("#FechaPago").on("change", function () {

        let ubicacion = $('#FechaPago').val()

        if (ubicacion == "") {
            alert("No Dejar el Campo vacio");
            return false;
        }
    })
})