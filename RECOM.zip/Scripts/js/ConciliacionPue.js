﻿
$(document).ready(function () {
    
    $body = $("body");

    $(document).on({
        ajaxStart: function () { $body.addClass("loading"); },
        ajaxStop: function () { $body.removeClass("loading"); }
    });
});

function fnEnviar() {

    if (window.FormData == undefined) {
        alert("Error: FormData is undefined");
    } else {
        var fileUpload = $("#fileToUpload").get(0);
        var files = fileUpload.files;

        var fileData = new FormData();

        var radioValueCompania = $("input[name='rbCompania']:checked").val();
        var radioValueTipoArchivo = $("input[name='rbTipoArchivo']:checked").val();

        if (radioValueCompania == undefined) {
            alert("Debe seleccionar un valor para la Compañia");
            return false;
        }

        if (radioValueTipoArchivo == undefined) {
            alert("Debe seleccionar un valor para el Tipo de Archivo");
            return false;
        }

        if (files.length == 0) {
            alert("Debe seleccionar un archivo CSV");
            return false;
        }

        fileData.append("rbCompania", radioValueCompania);
        fileData.append("rbTipoArchivo", radioValueTipoArchivo);
        fileData.append(files[0].name, files[0]);

        $.ajax({
            url: 'uploadFile',
            type: 'post',
            datatype: 'json',
            contentType: false,
            processData: false,
            async: false,
            data: fileData,
            success: function (response) {
                alert(response);
            }
        });
    }

    return true;
}

function fnGenArchivoSat() {

    var radioValueCompania = $("input[name='rbCompania']:checked").val();
    var anio = $(".cbAnio").val();
    var periodo = $(".cbPeriodo").val();
    var fileData = new FormData();

    if (radioValueCompania == undefined) {
        alert("Debe seleccionar un valor para la Compañia");
        return false;
    }

    if (anio == "0") {
        alert("Debe seleccionar un Año");
        return false;
    }

    if (periodo == "0") {
        alert("Debe seleccionar un Periodo");
        return false;
    }

    fileData.append("rbCompania", radioValueCompania);
    fileData.append("cbAnio", anio);
    fileData.append("cbPeriodo", periodo);

    llamadaAjax(fileData);

    return true;
}

function llamadaAjax(fileData) {
    $.ajax({
        url: 'GenArchivoSat',
        type: 'post',
        datatype: 'json',
        contentType: false,
        processData: false,
        async: false,
        cache: false,
        data: fileData,
        success: function (response) {
            if (response.code == 201) {
                window.location = 'Download?file=' + response.data;
            }
        }
    });
}
