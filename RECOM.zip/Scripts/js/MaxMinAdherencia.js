﻿$(document).ready(function () {
    $("#from-date").datepicker({
        dateFormat: "yy-mm-dd"
    });
    $("#to-date").datepicker({
        dateFormat: "yy-mm-dd"
    });

    $(".btn-buscar").on('click', function () {
        var fecha1 = $("#from-date").val();
        var fecha2 = $("#to-date").val();
        var claseManufactura = $("#clase-val").val();

        if (fecha1 == "" || fecha2 == "") {
            alert("Se requiere un rango de fechas")
            return false;
        }

        $('#ModalProcessing').modal('toggle');
        $("#tableResult tbody").html('');

        setTimeout(function () {
            //your code to be executed after 1 second
            GetOTs(fecha1, fecha2, claseManufactura);
        }, 1000);
        
    })

    $(".btn-buscar-oc").on('click', function () {
        var fecha1 = $("#from-date").val();
        var fecha2 = $("#to-date").val();
        var comprador = $("#buyer-val").val();
        var proveedor = $("#vendor-val").val();

        var claseManufactura = "";

        if (fecha1 == "" || fecha2 == "") {
            alert("Se requiere un rango de fechas")
            return false;
        }

        $('#ModalProcessing').modal('toggle')
        $("#tableResult tbody").html('');
        setTimeout(function () {
            //your code to be executed after 1 second
            GetOCs(fecha1, fecha2, comprador, proveedor);
        }, 1000);
        
    })

    $(".export-oc").on('click', function () {
        tablesToExcel(['tableResult'], ['OC'], 'AdherenciaOC.xls', 'Excel')
    })


    $(".export-ot").on('click', function () {
        tablesToExcel(['tableResult'], ['OT'], 'AdherenciaOT.xls', 'Excel')
    })
})

function GetOTs(fecha1, fecha2, claseManufactura) {
    $.ajax({
        type: "POST",
        url: "GetOT",
        data: { fechaInicial: fecha1, fechaFinal: fecha2, ptpPromo: claseManufactura },
        dataType: "json"

    }).done(function (response) {
        console.log(response);
        $('#ModalProcessing').modal('toggle')
        if (response.code == 201) {

            response.data.forEach(function (item, indice) {
                var clase = item.CantidadSugerida != item.CantidadConfirmada ? "marcar":"";

                var row = "<tr>" +
                    "<th>" + item.wo_nbr + "</th>" +
                    "<th>" + item.wo_part + "</th>" +
                    "<th>" + item["local-var04"] + "</th>" +
                    "<th class = " + clase +">" + item.CantidadSugerida + "</th>" +
                    "<th>" + item.CantidadConfirmada + "</th>" +
                    "<th>" + item.wo_qty_ord + "</th>" +
                    "<th>" + item.wo_qty_comp + "</th>" +

                    "<th>" + item.OtsHijas + "</th>" +

                    "<th>" + item.pt_promo + "</th>" +
                    "<th>" + item.FechaOT + "</th>" +
                    "<th>" + item.FecVencimiento + "</th>" +
                    "<th>" + item.wo_due_date + "</th>" +
                    "</tr>"
                $("#tableResult tbody").append(row);
            });

            
        } else {
            alert("Error al agregar")

        }

    }).fail(function (jqXHR) {
        alert("Error del servidor")
    });
}

function GetOCs(fecha1, fecha2, comprador, proveedor) {
    $.ajax({
        type: "POST",
        url: "GetOCs",
        data: { fechaInicial: fecha1, fechaFinal: fecha2, buyer: comprador, vendor: proveedor },
        dataType: "json"

    }).done(function (response) {
        console.log(response);

        $('#ModalProcessing').modal('toggle')
        if (response.code == 201) {

            response.data.forEach(function (item, indice) {
                var row = "<tr>" +
                    "<th>" + item.pod_nbr + "</th>" +
                    "<th>" + item.pod_line + "</th>" +
                    "<th>" + item.pod_part + "</th>" +
                    "<th>" + item["local-var00"] + "</th>" +
                    "<th>" + item.CantidadSugerida + "</th>" +
                    "<th>" + item.CantidadSolicitada + "</th>" +

                    "<th>" + item.pod_qty_ord + "</th>" +
                    "<th>" + item.pod_qty_rcvd + "</th>" +
                    "<th>" + item.po_vend + "</th>" +
                    "<th>" + item.ad_name + "</th>" +
                    "<th>" + item.po_buyer + "</th>" +

                    "<th>" + item.FecOrden + "</th>" +
                    "<th>" + item.FecPlanta + "</th>" +
                    "<th>" + item.pod_due_date + "</th>" +
                    "</tr>"
                $("#tableResult tbody").append(row);
            });

        } else {
            alert("Error al agregar")
        }

    }).fail(function (jqXHR) {
        alert("Error del servidor")
    });
}

var tablesToExcel = (function () {
    var uri = 'data:application/vnd.ms-excel;base64,'
        , tmplWorkbookXML = '<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
            + '<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office"><Author>Axel Richter</Author><Created>{created}</Created></DocumentProperties>'
            + '<Styles>'
            + '<Style ss:ID="Currency"><NumberFormat ss:Format="Currency"></NumberFormat></Style>'
            + '<Style ss:ID="Date"><NumberFormat ss:Format="Medium Date"></NumberFormat></Style>'
            + '</Styles>'
            + '{worksheets}</Workbook>'
        , tmplWorksheetXML = '<Worksheet ss:Name="{nameWS}"><Table>{rows}</Table></Worksheet>'
        , tmplCellXML = '<Cell{attributeStyleID}{attributeFormula}><Data ss:Type="{nameType}">{data}</Data></Cell>'
        , base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
        , format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
    return function (tables, wsnames, wbname, appname) {
        var ctx = "";
        var workbookXML = "";
        var worksheetsXML = "";
        var rowsXML = "";

        for (var i = 0; i < tables.length; i++) {
            if (!tables[i].nodeType) tables[i] = document.getElementById(tables[i]);
            for (var j = 0; j < tables[i].rows.length; j++) {
                rowsXML += '<Row>'
                for (var k = 0; k < tables[i].rows[j].cells.length; k++) {
                    var dataType = tables[i].rows[j].cells[k].getAttribute("data-type");
                    var dataStyle = tables[i].rows[j].cells[k].getAttribute("data-style");
                    var dataValue = tables[i].rows[j].cells[k].getAttribute("data-value");
                    dataValue = (dataValue) ? dataValue : tables[i].rows[j].cells[k].innerHTML;
                    var dataFormula = tables[i].rows[j].cells[k].getAttribute("data-formula");
                    dataFormula = (dataFormula) ? dataFormula : (appname == 'Calc' && dataType == 'DateTime') ? dataValue : null;
                    ctx = {
                        attributeStyleID: (dataStyle == 'Currency' || dataStyle == 'Date') ? ' ss:StyleID="' + dataStyle + '"' : ''
                        , nameType: (dataType == 'Number' || dataType == 'DateTime' || dataType == 'Boolean' || dataType == 'Error') ? dataType : 'String'
                        , data: (dataFormula) ? '' : dataValue
                        , attributeFormula: (dataFormula) ? ' ss:Formula="' + dataFormula + '"' : ''
                    };
                    rowsXML += format(tmplCellXML, ctx);
                }
                rowsXML += '</Row>'
            }
            ctx = { rows: rowsXML, nameWS: wsnames[i] || 'Sheet' + i };
            worksheetsXML += format(tmplWorksheetXML, ctx);
            rowsXML = "";
        }

        ctx = { created: (new Date()).getTime(), worksheets: worksheetsXML };
        workbookXML = format(tmplWorkbookXML, ctx);



        var link = document.createElement("A");
        link.href = uri + base64(workbookXML);
        link.download = wbname || 'Workbook.xls';
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
})();