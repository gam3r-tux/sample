﻿$(document).ready(function () {
    $(".btn-incremento").on('click', function () {
        let anio = $('#yearNumber').val();
        let incremento = $('#Incremento').val();
        setIncremento({
            anio: anio, incremento: incremento
        });
    })
})

function setIncremento(objData) {

    $.ajax({
        type: "POST",
        url: "AddIncremento",
        data: objData,
        dataType: "json"
    }).done(function (response) {
        console.log(response);
        if (response.code == 201) {

            alert("Se agrego");
        } else {
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}