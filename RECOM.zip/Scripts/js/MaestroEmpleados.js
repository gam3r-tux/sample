﻿$(document).ready(function () {
    $("#ObtenerME").on('click', function () {
        getMAestroEmpleados({});
    })
})

function getMAestroEmpleados(objData) {
    $.ajax({
        type: "POST",
        url: "HeadCount/GetMaestroEmpleados",
        data: objData,
        dataType: "json"

    }).done(function (response) {
        console.log(response);
        if (response.code == 201) {

            response.data.forEach(function (item, indice) {
                var row = "<tr>"+
                    "<th>"+item.IdTrabajador+"</th>"+
                    "<th>" + item.NombreTrabajador+"</th>"+
                    "<th>" + item.FechaIngreso+"</th>"+
                    "<th>" + item.FechaAntiguedad+"</th>"+
                    "<th>" + item.IdCentroGasto+"</th>"+
                    "<th>" + item.DescripcionCentroGasto+"</th>"+
                    "<th>" + item.IdPuesto+"</th>"+
                    "<th>" + item.DescripcionPuesto+"</th>"+
                    "<th>" + item.IdCelda+"</th>"+
                    "<th>" + item.DescripcionCelda+"</th>"+
                    "<th>" + item.IdGrupoNomina+"</th>"+
                    "<th>" + item.SalarioDiario+"</th>"+
                    "<th>" + item.SalarioIntegrado+"</th>"+
                "</tr>"
                $("#TME tbody").append(row);
            });
        } else {
        }

    }).fail(function (jqXHR) {
        console.log(jqXHR);
    });
}